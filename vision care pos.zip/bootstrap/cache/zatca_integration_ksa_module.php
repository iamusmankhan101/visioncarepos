<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ZatcaIntegrationKsa\\Providers\\ZatcaIntegrationKsaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ZatcaIntegrationKsa\\Providers\\ZatcaIntegrationKsaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);