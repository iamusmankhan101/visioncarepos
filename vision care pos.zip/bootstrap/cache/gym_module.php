<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Gym\\Providers\\GymServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Gym\\Providers\\GymServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);